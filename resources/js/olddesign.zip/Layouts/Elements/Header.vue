<template>
    <header class="ec-header">
        <div class="header-top">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col text-left header-top-left d-none d-lg-block">
                        <div class="header-top-social">
                            <span class="social-text text-upper">Follow us on:</span>
                            <ul class="mb-0">
                                <li class="list-inline-item">
                                    <a class="hdr-facebook" href="#"><i class="ecicon eci-facebook"></i></a>
                                </li>
                                <li class="list-inline-item">
                                    <a class="hdr-twitter" href="#"><i class="ecicon eci-twitter"></i></a>
                                </li>
                                <li class="list-inline-item">
                                    <a class="hdr-instagram" href="#"><i class="ecicon eci-instagram"></i></a>
                                </li>
                                <li class="list-inline-item">
                                    <a class="hdr-linkedin" href="#"><i class="ecicon eci-linkedin"></i></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <a href="#ec-mobile-sidebar" class="ec-header-btn ec-sidebar-toggle d-lg-none">
                        <img src="/images/icons/category-icon.svg" class="svg_img header_svg" alt="icon" />
                    </a>
                     <div class="col header-top-right d-none d-lg-block">
                        <div class="header-top-right-inner d-flex justify-content-end" v-if="$page.props.auth.user">
                            <div class="ec-header-bottons">
                                <div class="ec-header-user dropdown">
                                    <button class="dropdown-toggle" data-bs-toggle="dropdown">
                                        <img src="/images/icons/user.png" width="18" class="mr-1" alt="Account" /> 
                                        My Account,
                                    </button>
                                    <ul class="dropdown-menu dropdown-menu-right">
                                        <li class="heading">Welcome {{ $page.props.auth.user.name }}</li>
                                        <li>
                                            <Link class="dropdown-item" :href="route('dashboard')">Dashboard</Link>
                                        </li>
                                        <li>
                                            <Link class="dropdown-item" :href="route('profile')">Profile</Link>
                                        </li>
                                        <li>
                                            <Link class="dropdown-item" :href="route('wishlist')">Wishlist</Link>
                                        </li>
                                        <li>
                                            <Link class="dropdown-item" :href="route('orders')">Orders</Link>
                                        </li>
                                        <li>
                                            <Link class="dropdown-item" :href="route('addresses')">Addresses</Link>
                                        </li>
                                        <li>
                                            <Link class="dropdown-item" method="post" as="button" :href="route('logout')">Logout</Link>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="header-top-right-inner d-flex justify-content-end" v-else>
                            <div class="ec-header-user dropdown mr-2">
                                <Link :href="route('login')">
                                   <img src="/images/icons/enter.png" width="18" class="mr-1" alt="Login" /> Login
                                </Link>
                            </div>
                            <div class="ec-header-wishlist">
                                <Link :href="route('register')">
                                   <img src="/images/icons/register.png" width="18" class="mr-1" alt="Register" /> Register 
                                </Link>
                            </div>
                        </div>
                    </div>
                    <div class="col d-lg-none ">
                        <div class="ec-header-bottons">
                            <div class="ec-header-user dropdown">
                                <Link :href="route('login')" class="ec-header-btn">
                                    <img src="/images/icons/user.svg" class="svg_img header_svg" alt="" />
                                </Link>
                            </div>
                            <a href="wishlist.html" class="ec-header-btn ec-header-wishlist">
                                <div class="header-icon">
                                    <img src="/images/icons/wishlist.svg" class="svg_img header_svg" alt="" />
                                </div>
                                <span class="ec-header-count">4</span>
                            </a>
                            <!-- Header Cart End -->
                            <!-- Header Cart Start -->
                            <a href="javascript:;" @click="$emit('show-sidecart')" class="ec-header-btn ec-side-toggle">
                                <div class="header-icon">
                                    <img src="/images/icons/cart.svg" class="svg_img header_svg" alt="" />
                                </div>
                                <span class="ec-header-count ec-cart-count cart-count-lable">3</span>
                            </a>
                            <!-- Header Cart End -->
                            <!-- Header menu Start -->
                            <a href="#ec-mobile-menu" class="ec-header-btn ec-side-toggle d-lg-none">
                                <img src="/images/icons/menu.svg" class="svg_img header_svg" alt="icon" />
                            </a>
                            <!-- Header menu End -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="ec-header-bottom d-none d-lg-block">
            <div class="container position-relative">
                <div class="row">
                    <div class="ec-flex">
                        <!-- Ec Header Logo Start -->
                        <div class="align-self-center">
                            <div class="header-logo">
                                <a target="_self" href="/">
                                    <img src="/images/logo.png" alt="Veeere" />
                                    <img class="dark-logo" src="/images/logo.png" alt="Veeere" style="display: none;" />
                                </a>
                            </div>
                        </div>
                        <div class="align-self-center">
                            <div class="header-search">
                                <form class="ec-btn-group-form" action="#">
                                    <input class="form-control" placeholder="Enter Your Product Name..." type="text">
                                    <button class="submit" type="submit">
                                        <img src="/images/icons/search.svg" class="svg_img header_svg" alt="" />
                                    </button>
                                </form>
                            </div>
                        </div>
                        <div class="align-self-center">
                            <div class="ec-header-bottons">
                                <!-- <Link href="/wishlists" class="ec-header-btn ec-header-wishlist">
                                    <div class="header-icon"><img src="/images/icons/wishlist.svg"
                                            class="svg_img header_svg" alt="" /></div>
                                     <span class="ec-header-count">4</span> 
                                </Link> -->
                                <!-- Header wishlist End -->
                                <a href="javascript:;" @click="$emit('show-sidecart')" class="ec-header-btn ec-side-toggle">
                                    <div class="header-icon">
                                        <img src="/images/icons/cart_5.svg" class="svg_img header_svg" alt="" />
                                    </div>
                                    <span class="ec-btn-title">
                                        <span class="ec-cart-count">{{cartQuantity}}</span> item(s) - 
                                        <price :price="cartTotal" :currency="currencyIcon"></price>
                                    </span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="ec-header-bottom d-lg-none">
            <div class="container position-relative">
                <div class="row ">
                    <div class="col">
                        <div class="header-logo">
                            <Link :href="route('home')">
                                <img src="/images/logo.png" alt="Veeere" />
                                <img class="dark-logo" src="/images/logo.png" alt="Veeere" style="display: none;" />
                            </Link>
                        </div>
                    </div>
                    <div class="col">
                        <div class="header-search">
                            <form class="ec-btn-group-form" action="#">
                                <input class="form-control" placeholder="Enter Your Product Name..." type="text">
                                <button class="submit" type="submit">
                                    <img src="/images/icons/search.svg" class="svg_img header_svg" alt="icon" />
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <theme-menu v-on:show-sidecart="$emit('show-sidecart')" />
    </header>
</template>
<script>
import ThemeMenu from "@/Layouts/Elements/Menu.vue";
import { mapGetters } from 'vuex';
import Price from '@/Pages/Product/Elemants/Price.vue';
import ApplicationLogo from '@/Components/ApplicationLogo.vue';

export default {
    components: {
        ThemeMenu,
        Price,
        ApplicationLogo
    },
    emits:[
        'show-sidecart'
    ],
    computed:{
        ...mapGetters(['cartTotal', 'cartQuantity']),
        currencyIcon() {
            return 'Rs. ';
        },
    },
};
</script>