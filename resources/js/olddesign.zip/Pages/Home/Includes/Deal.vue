<script>
import {Countdown} from 'vue3-flip-countdown'
export default {
    components: {
        Countdown
    }    
}
</script>
<template>
    <div class="row space-t-50">
        <div class="ec-spe-section col-lg-12 col-md-12 col-sm-12 sectopn-spc-mb">
            <div class="col-md-12">
                <div class="section-title">
                    <h2 class="ec-title">Deal of the day</h2>
                </div>
            </div>

            <div class="ec-spe-products no-border">
                <div class="ec-spe-product">
                    <div class="ec-spe-pro-inner border">
                        <div class="ec-spe-pro-image-outer col-md-6 col-sm-12">
                            <div class="ec-spe-pro-image">
                                <img class="img-responsive" src="/images/product-image/77_1.jpg" alt="">                                                                              
                            </div>
                        </div>
                        <div class="ec-spe-pro-content col-md-6 col-sm-12">
                            <div class="ec-spe-pro-rating">
                                <span class="ec-spe-rating-icon">
                                    <i class="ecicon eci-star fill"></i>
                                    <i class="ecicon eci-star fill"></i>
                                    <i class="ecicon eci-star fill"></i>
                                    <i class="ecicon eci-star"></i>
                                    <i class="ecicon eci-star"></i>
                                </span>
                            </div>
                            <h5 class="ec-spe-pro-title"><a href="product-left-sidebar.html">Organic Mango 20kg Box</a></h5>
                            <div class="ec-spe-pro-desc">Lorem ipsum dolor sit amet consectetur Lorem ipsum
                                dolor dolor sit amet consectetur Lorem ipsum dolor</div>
                            <div class="ec-spe-price">
                                <span class="new-price">Rs. 199.00</span>
                                <span class="old-price">Rs. 280.00</span>
                            </div>
                            <div class="ec-spe-pro-btn">
                                <a href="#" class="btn btn-lg btn-primary">Add To Cart</a>
                            </div>
                            <div class="ec-spe-pro-progress">
                                <span class="ec-spe-pro-progress-desc"><span>Sold:
                                        <b>15</b></span><span>Available: <b>40</b></span></span>
                                <span class="ec-spe-pro-progressbar"></span>
                            </div>
                            <div class="countdowntimer">
                                <span class="ec-spe-count-desc"> Hurry Up! Offer ends in:</span>
                                <Countdown deadline="2022-05-21 23:59:59" :flipAnimation="false" />
                            </div>

                        </div>
                    </div>
                </div>
                <div class="ec-spe-product">
                    <div class="ec-spe-pro-inner border">
                        <div class="ec-spe-pro-image-outer col-md-6 col-sm-12">
                            <div class="ec-spe-pro-image">
                                <img class="img-responsive"
                                            src="/images/product-image/78_1.jpg" alt="">
                            </div>
                        </div>
                        <div class="ec-spe-pro-content col-md-6 col-sm-12">
                            <div class="ec-spe-pro-rating">
                                <span class="ec-spe-rating-icon">
                                    <i class="ecicon eci-star fill"></i>
                                    <i class="ecicon eci-star fill"></i>
                                    <i class="ecicon eci-star fill"></i>
                                    <i class="ecicon eci-star"></i>
                                    <i class="ecicon eci-star"></i>
                                </span>
                            </div>
                            <h5 class="ec-spe-pro-title"><a href="product-left-sidebar.html">Fresh organic Apple 12 Pcs</a></h5>
                            <div class="ec-spe-pro-desc">Lorem ipsum dolor sit amet consectetur Lorem ipsum
                                dolor dolor sit amet consectetur Lorem ipsum dolor</div>
                            <div class="ec-spe-price">
                                <span class="new-price">Rs. 199.00</span>
                                <span class="old-price">Rs. 280.00</span>
                            </div>
                            <div class="ec-spe-pro-btn">
                                <a href="#" class="btn btn-lg btn-primary">Add To Cart</a>
                            </div>
                            <div class="ec-spe-pro-progress">
                                <span class="ec-spe-pro-progress-desc"><span>Sold:
                                        <b>20</b></span><span>Available: <b>40</b></span></span>
                                <span class="ec-spe-pro-progressbar"></span>
                            </div>
                            <div class="countdowntimer">
                                <span class="ec-spe-count-desc"> Hurry Up! Offer ends in:</span>
                                <Countdown deadline="2022-05-21 23:59:59"  :flipAnimation="false" />
                            </div>

                        </div>
                    </div>
                </div>
                <div class="ec-spe-product">
                    <div class="ec-spe-pro-inner border">
                        <div class="ec-spe-pro-image-outer col-md-6 col-sm-12">
                            <div class="ec-spe-pro-image">
                                <img class="img-responsive" src="/images/product-image/77_1.jpg" alt="">                                                                              
                            </div>
                        </div>
                        <div class="ec-spe-pro-content col-md-6 col-sm-12">
                            <div class="ec-spe-pro-rating">
                                <span class="ec-spe-rating-icon">
                                    <i class="ecicon eci-star fill"></i>
                                    <i class="ecicon eci-star fill"></i>
                                    <i class="ecicon eci-star fill"></i>
                                    <i class="ecicon eci-star"></i>
                                    <i class="ecicon eci-star"></i>
                                </span>
                            </div>
                            <h5 class="ec-spe-pro-title"><a href="product-left-sidebar.html">Organic Mango 20kg Box</a></h5>
                            <div class="ec-spe-pro-desc">Lorem ipsum dolor sit amet consectetur Lorem ipsum
                                dolor dolor sit amet consectetur Lorem ipsum dolor</div>
                            <div class="ec-spe-price">
                                <span class="new-price">Rs. 199.00</span>
                                <span class="old-price">Rs. 280.00</span>
                            </div>
                            <div class="ec-spe-pro-btn">
                                <a href="#" class="btn btn-lg btn-primary">Add To Cart</a>
                            </div>
                            <div class="ec-spe-pro-progress">
                                <span class="ec-spe-pro-progress-desc"><span>Sold:
                                        <b>15</b></span><span>Available: <b>40</b></span></span>
                                <span class="ec-spe-pro-progressbar"></span>
                            </div>
                            <div class="countdowntimer">
                                <span class="ec-spe-count-desc"> Hurry Up! Offer ends in:</span>
                                <Countdown deadline="2022-05-21 23:59:59" :flipAnimation="false" />
                            </div>

                        </div>
                    </div>
                </div>
                <div class="ec-spe-product">
                    <div class="ec-spe-pro-inner border">
                        <div class="ec-spe-pro-image-outer col-md-6 col-sm-12">
                            <div class="ec-spe-pro-image">
                                <img class="img-responsive"
                                            src="/images/product-image/78_1.jpg" alt="">
                            </div>
                        </div>
                        <div class="ec-spe-pro-content col-md-6 col-sm-12">
                            <div class="ec-spe-pro-rating">
                                <span class="ec-spe-rating-icon">
                                    <i class="ecicon eci-star fill"></i>
                                    <i class="ecicon eci-star fill"></i>
                                    <i class="ecicon eci-star fill"></i>
                                    <i class="ecicon eci-star"></i>
                                    <i class="ecicon eci-star"></i>
                                </span>
                            </div>
                            <h5 class="ec-spe-pro-title"><a href="product-left-sidebar.html">Fresh organic Apple 12 Pcs</a></h5>
                            <div class="ec-spe-pro-desc">Lorem ipsum dolor sit amet consectetur Lorem ipsum
                                dolor dolor sit amet consectetur Lorem ipsum dolor</div>
                            <div class="ec-spe-price">
                                <span class="new-price">Rs. 199.00</span>
                                <span class="old-price">Rs. 280.00</span>
                            </div>
                            <div class="ec-spe-pro-btn">
                                <a href="#" class="btn btn-lg btn-primary">Add To Cart</a>
                            </div>
                            <div class="ec-spe-pro-progress">
                                <span class="ec-spe-pro-progress-desc"><span>Sold:
                                        <b>20</b></span><span>Available: <b>40</b></span></span>
                                <span class="ec-spe-pro-progressbar"></span>
                            </div>
                            <div class="countdowntimer">
                                <span class="ec-spe-count-desc"> Hurry Up! Offer ends in:</span>
                                <Countdown deadline="2022-05-22 23:59:59" :flipAnimation="false" />
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>