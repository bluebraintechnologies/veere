<template>
    <div class="ec-main-slider section section-space-pb-30">
        <div class="container">
            <div class="ec-slider swiper-container main-slider-nav main-slider-dot">
            <!-- Main slider -->
                <div class="swiper-wrapper">
                    <div class="ec-slide-item swiper-slide d-flex slide-1"  v-for="(sdata,index) in sliders" :key="'slide-'+index" :style="'background-image:url('+sdata.image+')'">
                        
                    </div>
                </div>
                <div class="swiper-pagination swiper-pagination-white"></div>
                <div class="swiper-buttons">
                    <div class="swiper-button-next"></div>
                    <div class="swiper-button-prev"></div>
                </div>
            </div>
        </div>
    </div>  
</template>
<script>
export default {
    props: {
        sliders: [Array, Object],
    },
};
</script>