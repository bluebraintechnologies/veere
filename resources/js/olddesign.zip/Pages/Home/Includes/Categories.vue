<template>
    <section class="section ec-category-section section-space-p">
        <div class="container">
            <div class="row d-none">
                <div class="col-md-12">
                    <div class="section-title">
                        <h2 class="ec-title">Top Category</h2>
                    </div>
                </div>
            </div>
            <div class="row margin-minus-b-15 margin-minus-t-15">
                <div id="ec-cat-slider">
                <div class="ec_cat_content ec_cat_content_1 col-sm-12 col-md-6 col-lg-3" v-for="(sitem, sk) in slides" :key="'cat'+sk">
                    <div class="ec_cat_inner ec_cat_inner-1">
                        <div class="ec-category-image">
                            <img src="/images/icons/drink-7.svg" class="svg_img" :alt="sitem.name" />
                        </div>
                        <div class="ec-category-desc">
                            <h3> {{ sitem.name }} <span title="Category Items"></span></h3>
                            <Link :href="route('category', sitem.slug)" class="cat-show-all">
                                Show All <i class="ecicon eci-angle-double-right" aria-hidden="true"></i>
                            </Link>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </section>
</template>
<script>

export default {
    props: {
        slides:[Array, Object]
    },
    mounted() {
    }
}
</script>