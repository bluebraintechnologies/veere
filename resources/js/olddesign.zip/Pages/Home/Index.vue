<script>
import MainLayout from "@/Layouts/Main.vue";

import Categories from "./Includes/Categories.vue";
import MainSlider from "./Includes/MainSlider.vue";
import Blogs from './Includes/Blogs.vue';
import FeaturedProducts from './Includes/FeaturedProducts.vue';
import ProductsGroup from './Includes/ProductsGroup.vue';
import Deal from './Includes/Deal.vue';
import Offers from './Includes/Offers.vue';


export default {
    components: {
      MainLayout,
      Blogs,
      FeaturedProducts,
      Categories,
      MainSlider,
      Deal,
      Offers,
      ProductsGroup
    },
    data() {
        return {
          sideCartStatus: false,
        };
    },
    props: {
      sliders:[Array, Object],
      categories:[Array, Object],
      featured_category:[Array, Object],
      featured_products:[Array, Object],
      top_selling:[Array, Object],
      top_rated:[Array, Object],
      best_sellers:[Array, Object],
      new_arrivals:[Array, Object]
    },
    
    methods: {
      displaySideCart() {
        this.sideCartStatus = !this.sideCartStatus;
      },
      
    },
    created(){
      
    }
};
</script>
<template>
  <Head title="Home" />
  <MainLayout>
      <Categories :slides="categories" />
      <MainSlider :sliders="sliders" />
      <section class="section ec-product-tab section-space-p">
        <div class="container">
          <FeaturedProducts :products="featured_products" :categories="featured_category" />
          <ProductsGroup :top-selling="top_selling" :top-rated="top_rated" :best-sellers="best_sellers" :new-arrivals="new_arrivals" />
          <Deal />
        </div>
      </section>
      <Offers />
      <Blogs />
  </MainLayout>  
</template>
